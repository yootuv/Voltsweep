﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NationalInstruments.Visa;

namespace ConsoleApp3
{
    class Program
    {
        static private int Delay_Time_PS = 1000;//系统延时时间设置，单位是毫秒，1000ms=1s
        static private MessageBasedSession PS_Session, DM_Session;//定义电源和万用电表会话窗口对象

        private static void Connect()//仪器连接
        {
            using (var rmSession = new ResourceManager())
            {
                PS_Session = (MessageBasedSession)rmSession.Open("USB0::0x05E6::0x2230::9102789::INSTR");//需修改电源的USB地址，以完成会话窗口的创建
                Console.WriteLine("电源连接成功");
                DM_Session = (MessageBasedSession)rmSession.Open("USB0::0x05E6::0x6500::04435250::INSTR");//需修改万用电表的USB地址，以完成会话窗口的创建
                Console.WriteLine("万用表连接成功");
            }
        }

        private static void Voltsweep()
        {
            double init = 3.3, start = 3, end = 10, step = 0.1;//设置扫电压的初始值，开始、结束、步长
            int step_counts = 0;//计量步数
            if (start > end)//判断是升压或降压，start>end是降压，start<end是升压
            {
                step_counts = (int)((start - end) / step) + 1;//计算执行扫电压次数
                step = (-1) * step;
            }
            else if (start < end)
            {
                step_counts = (int)((end - start) / step) + 1;
            }
            Console.WriteLine("步数为:" + step_counts);
            PS_Session.RawIO.Write("SYST:REM");//电源进入程控模式
            PS_Session.RawIO.Write("OUTP ON");//电源输出电压
            DM_Session.RawIO.Write("TRAC:CLE");//清除万用表defbuffer1
            //DM_Session.RawIO.Write("VOLT:NPLC 0.001");
            PS_Session.RawIO.Write("APPL CH1," + init.ToString());//设置电源输出初始电压
            
            Thread.Sleep(Delay_Time_PS);
            DM_Session.RawIO.Write("MEAS:DIG:VOLT?");//令万用电表进行电压量测
            //DM_Session.RawIO.Write("READ
            Console.WriteLine("通道1输出电压:" + init.ToString());
            Console.WriteLine("万用电表量测电压:" + (double.Parse(DM_Session.RawIO.ReadString())).ToString());//打印从万用电表读取测量到的数值
            //Thread.Sleep(Delay_Time_PS);//进行延时

            for (int eaah_step = 0; eaah_step < step_counts; eaah_step++)//进行总步数次循环
            {
                //Thread.Sleep(Delay_Time_PS);
                if (eaah_step != 0)//次步为跳过开始第一个电压进行加步长
                    start += step;

                PS_Session.RawIO.Write("APPL CH1," + start.ToString());//进行电压的逐一输出
                

                Thread.Sleep(Delay_Time_PS);
                //DM_Session.RawIO.Write("VOLT:DEL:AUTO OFF");
                DM_Session.RawIO.Write("VOLT:NPLC 0.001");
                DM_Session.RawIO.Write("MEAS:DIG:VOLT?");//令万用电表进行电压量测
                //DM_Session.RawIO.Write("READ:DIG
                Console.WriteLine("通道1输出电压:" + start.ToString());
                Console.WriteLine("万用电表量测电压:" + (double.Parse(DM_Session.RawIO.ReadString())).ToString());//打印从万用电表读取测量到的数值
                //Thread.Sleep(Delay_Time_PS);

            }
            //DM_Session.RawIO.Write("TRAC:CLE \"voltage\"");
            PS_Session.RawIO.Write("OUTP OFF");//电源输出关闭
            PS_Session.RawIO.Write("SYST:LOC");//设置电源为本地模式
            Console.ReadKey();
        }

        static void Main(string[] args)
        {
            Connect();
            Voltsweep();
        }
    }
}

